"""
Particle identification and dE/dx estimation from a tracking detector.

Physics background
------------------
Each track gives up to 50 repeated measurements of energy loss per unit path
length (dE/dx). Individual samples follow a Landau distribution: a sharp peak
near the "most probable value" with a long high tail from rare large energy
transfers (delta rays). The single physically meaningful quantity for a track
is that peaked value, NOT the arithmetic mean (which the tail biases upward and
inflates by huge outliers such as the 70000 keV/cm samples seen in the data).

The standard experimental estimator is the *truncated mean*: sort the samples,
drop the highest fraction, average the rest. This suppresses the Landau tail and
yields a stable estimate of the true energy loss. We use the lowest 60%.

For classification, dE/dx depends on velocity (beta*gamma = p/m), so at a given
momentum different species sit at different dE/dx. We therefore feed the
classifier the per-event dE/dx estimate (and related distribution statistics)
together with the momentum and physics-motivated combinations.
"""

import json
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score

TRUNC = 0.60  # keep lowest 60% of samples for the truncated mean

# ---------------------------------------------------------------- load
train = pd.read_csv("train.csv")
test = pd.read_csv("test_input.csv")
dedx_cols = [c for c in train.columns if c.startswith("dedx")]


def truncated_mean(sorted_x, frac=TRUNC):
    k = max(1, int(len(sorted_x) * frac))
    return sorted_x[:k].mean()


def event_features(V):
    """Turn each event's raw dedx samples into an estimate + shape features."""
    est = np.empty(len(V))
    feats = np.empty((len(V), 14))
    for i, row in enumerate(V):
        x = np.sort(row[np.isfinite(row)])
        n = len(x)
        tm60 = truncated_mean(x, 0.60)
        tm50 = truncated_mean(x, 0.50)
        p = np.percentile(x, [10, 20, 30, 40, 50, 60, 70, 80, 90])
        est[i] = tm60
        feats[i] = [tm60, tm50, x.mean(), x.std(), n] + list(p)
    return est, feats


train_est, train_shape = event_features(train[dedx_cols].values)
test_est, test_shape = event_features(test[dedx_cols].values)


def build_X(shape, mom_series):
    """Combine per-event shape features with momentum-based physics features."""
    mom = mom_series.fillna(mom_series.median()).values.reshape(-1, 1)
    momflag = mom_series.isna().values.reshape(-1, 1).astype(float)
    tm = shape[:, [0]]  # the truncated-mean estimate
    return np.hstack([
        shape,
        mom, np.log(mom),
        np.log(tm),
        tm / mom,      # ~ separates species via 1/beta^2 rise
        tm * mom,
        momflag,
    ])


# momentum median from train, reused for test to avoid leakage
mom_median = train["momentum"].median()
Xtr = build_X(train_shape, train["momentum"])
Xte = build_X(test_shape, test["momentum"].fillna(mom_median))
ytr = train["particle"].values

# ---------------------------------------------------------------- validate
clf = RandomForestClassifier(n_estimators=400, random_state=0, n_jobs=-1)
cv = cross_val_score(clf, Xtr, ytr, cv=5)
cv_acc = float(cv.mean())
print(f"5-fold CV accuracy: {cv_acc:.4f}  (folds: {np.round(cv,4)})")

# ---------------------------------------------------------------- fit + predict
clf.fit(Xtr, ytr)
pred = clf.predict(Xte)

out = pd.DataFrame({
    "event_id": test["event_id"].values,
    "dedx_est": test_est,
    "particle": pred,
})
out.to_csv("test_pred.csv", index=False)
print(f"Wrote test_pred.csv ({len(out)} rows)")

# ---------------------------------------------------------------- summary
summary = {
    "dedx_estimator": (
        "Truncated mean of each event's repeated dedx samples: sort the finite "
        "samples and average the lowest 60%. dedx samples follow a Landau "
        "distribution with a long high tail (and extreme outliers up to ~70000 "
        "keV/cm), so the plain mean is biased and unstable. The truncated mean is "
        "the standard detector estimator of the true (most-probable) energy loss "
        "and is robust to the tail."
    ),
    "model_type": "Random forest classifier (400 trees)",
    "features": [
        "truncated_mean_60 (=dedx_est)", "truncated_mean_50",
        "sample_mean", "sample_std", "n_measurements",
        "percentiles_10_20_30_40_50_60_70_80_90",
        "momentum", "log_momentum", "log_truncated_mean",
        "truncated_mean/momentum", "truncated_mean*momentum",
        "momentum_missing_flag",
    ],
    "data_preparation": (
        "Per event, dropped missing (NaN) dedx samples before computing "
        "statistics (each event still has 29-50 valid samples). Missing momentum "
        "(203/5000 train rows) imputed with the train-set median and flagged with "
        "a binary feature. Applied truncation rather than removing outlier rows, "
        "since the outliers are physical Landau tail samples, not corrupt data."
    ),
    "validation": (
        f"Stratified-by-default 5-fold cross-validation on train.csv, "
        f"accuracy = {cv_acc:.4f}."
    ),
    "reasoning": (
        "dE/dx depends on velocity beta*gamma = p/m, so at fixed momentum species "
        "separate by their dedx: electrons sit on the minimum-ionizing plateau "
        "(~2 keV/cm) at all momenta and are cleanly identified, while heavier "
        "species (proton/deuteron/kaon) rise via the 1/beta^2 term at low "
        "momentum but converge toward the plateau at high momentum, causing "
        "intrinsic overlap. Feeding the robust truncated-mean estimate together "
        "with momentum and the tm/momentum ratio lets the forest exploit this "
        "structure."
    ),
}
with open("model_summary.json", "w") as f:
    json.dump(summary, f, indent=2)
print("Wrote model_summary.json")
