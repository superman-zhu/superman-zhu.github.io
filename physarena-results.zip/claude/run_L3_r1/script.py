"""
Particle detector analysis.

Goal
----
For every event in test_input.csv predict:
  1. dedx_est -- a single best estimate of the event's true energy loss per unit
     path length, derived from that event's own repeated dedx_01..dedx_50 samples.
  2. particle -- the species that produced the event.

Key physics / statistics observations that drive the choices below
-------------------------------------------------------------------
* Energy-loss samples along a track follow a Landau-like distribution: strongly
  right-skewed with a long high tail (a handful of large "delta-ray" hits).
  Globally the median dedx is ~2.0 keV/cm but the max is ~7e4 keV/cm.
  => The arithmetic mean is dominated by the tail and is a poor, high-variance
     estimate of the true (most-probable) energy loss. The standard detector
     technique is the *truncated mean*: sort the samples, drop the highest ones,
     average the rest. We keep the lowest 60% (drop the top 40%).
* Each event has a variable number of usable samples (29..50; some dedx cells are
  blank), so the truncation is done on the count actually present per event.
* ~4% of events have no momentum value. HistGradientBoostingClassifier handles
  NaN features natively, so those rows are kept as-is (no imputation) and the
  model routes missing-momentum events down a dedicated branch.
* Species separate by mass through the Bethe-Bloch relation: at a given momentum
  dedx orders by particle mass. Electrons (lightest) separate cleanly; the heavy
  hadrons (proton/kaon/deuteron) overlap and are the main source of error.
  Features fed to the classifier are the truncated-mean dedx estimate plus
  momentum-based terms that let the model learn the dedx-vs-momentum bands.
"""

import json
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score

TRUNC_KEEP = 0.60          # fraction of lowest samples kept in the truncated mean
DEDX_COLS = [f"dedx_{i:02d}" for i in range(1, 51)]


def event_summaries(dedx_matrix):
    """Reduce each event's repeated measurements to summary quantities.

    Returns a DataFrame with, per event:
      tm   -- truncated mean (mean of the lowest TRUNC_KEEP fraction of samples);
              our robust estimate of the true energy loss.
      med  -- median of the samples (secondary robust location).
      std  -- spread of the truncated sample set.
      n    -- number of usable (non-missing) samples.
    """
    tm, med, std, n = [], [], [], []
    for row in dedx_matrix:
        v = np.sort(row[~np.isnan(row)])
        nn = len(v)
        k = max(1, int(np.ceil(nn * TRUNC_KEEP)))
        kept = v[:k]
        tm.append(kept.mean())
        med.append(np.median(v))
        std.append(kept.std())
        n.append(nn)
    return pd.DataFrame(
        {"tm": tm, "med": med, "std": std, "n": n},
        dtype=float,
    )


def build_features(df):
    """Feature matrix: event summaries + momentum terms (with interactions)."""
    summ = event_summaries(df[DEDX_COLS].to_numpy(dtype=float))
    mom = df["momentum"].to_numpy(dtype=float)
    summ["mom"] = mom
    # log(momentum) is NaN where momentum is missing; HGB handles NaN natively.
    with np.errstate(invalid="ignore", divide="ignore"):
        summ["logmom"] = np.log(mom)
    summ["tm_mom"] = summ["tm"] * mom          # tracks the dedx-vs-p band structure
    return summ[["tm", "med", "mom", "logmom", "tm_mom", "std", "n"]]


def main():
    train = pd.read_csv("train.csv")
    test = pd.read_csv("test_input.csv")

    X_train = build_features(train)
    y_train = train["particle"].to_numpy()
    X_test = build_features(test)

    clf = HistGradientBoostingClassifier(random_state=0)

    # ---- Validation: 5-fold stratified CV on data the model never trained on ----
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
    cv_scores = cross_val_score(clf, X_train, y_train, cv=cv, scoring="accuracy")
    cv_acc = float(cv_scores.mean())
    print(f"5-fold CV accuracy: {cv_acc:.4f}  (folds: {np.round(cv_scores, 3)})")

    # ---- Fit on all training data, predict the test set ----
    clf.fit(X_train, y_train)
    pred_species = clf.predict(X_test)

    # dedx_est is the per-event truncated mean (our robust energy-loss estimate).
    dedx_est = event_summaries(test[DEDX_COLS].to_numpy(dtype=float))["tm"].to_numpy()

    out = pd.DataFrame(
        {
            "event_id": test["event_id"].to_numpy(),
            "dedx_est": dedx_est,
            "particle": pred_species,
        }
    )
    out.to_csv("test_pred.csv", index=False)
    print(f"Wrote test_pred.csv with {len(out)} rows.")

    summary = {
        "dedx_estimator": (
            "Truncated mean of each event's repeated dedx samples: sort the "
            "non-missing samples, keep the lowest 60%, average them. The samples "
            "are Landau-distributed (strongly right-skewed with a long high tail "
            "from delta rays), so the arithmetic mean is inflated and high-"
            "variance; truncating the tail is the standard detector technique and "
            "gives a low-variance estimate of the true (most-probable) energy loss."
        ),
        "model_type": "Gradient-boosted decision trees (HistGradientBoostingClassifier)",
        "features": ["tm", "med", "mom", "logmom", "tm_mom", "std", "n"],
        "data_preparation": (
            "Per event, dropped blank dedx cells (events have 29-50 usable samples) "
            "and computed the truncated mean on the samples actually present. "
            "Missing momentum (~4% of events) was left as NaN rather than imputed, "
            "because HistGradientBoostingClassifier handles NaN natively and routes "
            "those events down a dedicated split; no scaling was needed for trees."
        ),
        "validation": (
            f"5-fold stratified cross-validation (accuracy) on held-out folds the "
            f"model never trained on. Mean accuracy = {cv_acc:.4f}."
        ),
        "reasoning": (
            "Within each event the repeated measurements are right-skewed (Landau), "
            "so a truncated mean beats the arithmetic mean as an energy-loss "
            "estimate. Across events, species separate via the Bethe-Bloch "
            "dedx-vs-momentum relation, so feeding the truncated-mean dedx together "
            "with momentum terms lets the trees learn the mass-ordered bands; "
            "electrons separate cleanly while the heavy hadrons overlap most."
        ),
    }
    with open("model_summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    print("Wrote model_summary.json.")


if __name__ == "__main__":
    main()
