"""
Particle detector analysis.

Two deliverables per test event:
  1. dedx_est -- best estimate of the event's true energy loss (keV/cm).
  2. particle -- predicted species.

Key data facts discovered by inspection of train.csv (see model_summary.json):
  * The 50 dedx_XX columns are repeated dE/dx samples along one track. Within a
    single event they follow a strongly right-skewed (Landau-like) distribution:
    median within-event skew ~3.9, with rare very large values (up to 1e4+).
    -> The arithmetic mean is a terrible summary (dominated by the tail). A
       TRUNCATED MEAN -- sort the samples, drop the high tail, average the rest --
       is the standard, robust estimator of the true (most-probable) energy loss.
       Measured within homogeneous (species, momentum) cells, the truncated mean's
       coefficient of variation is ~0.06 vs ~0.74 for the full mean.
  * Not every event has 50 samples (valid count ranges ~28-50); truncation is done
    on each event's own available samples.
  * Momentum is missing for ~4% of events. dedx alone still carries information, and
    the gradient-boosting model handles missing momentum natively (no imputation).
  * Species separability is uneven: electrons (flat, minimum-ionizing near 2 keV/cm)
    separate cleanly; proton/kaon/deuteron overlap heavily because their Bethe-Bloch
    curves cross in this 1-10 GeV/c range.
"""

import json
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import cross_val_predict, StratifiedKFold
from sklearn.metrics import accuracy_score

DEDX_COLS = [f"dedx_{i:02d}" for i in range(1, 51)]

# Fraction of (low) samples kept for the REPORTED dedx estimate. A moderate
# truncation (drop the top 40%) removes the Landau tail while staying close to
# the true most-probable energy loss -- near-optimal precision, low bias.
REPORT_KEEP = 0.60


def truncated_mean(matrix, keep):
    """Per-row truncated mean: sort each row's non-NaN values, keep the lowest
    `keep` fraction, average them. Robust to the heavy upper (Landau) tail."""
    out = np.full(matrix.shape[0], np.nan)
    for i in range(matrix.shape[0]):
        v = matrix[i]
        v = v[~np.isnan(v)]
        if v.size == 0:
            continue
        v.sort()
        b = max(1, int(np.ceil(keep * v.size)))
        out[i] = v[:b].mean()
    return out


def build_features(df):
    """Turn each event into model features.

    Multiple truncated means at different keep-fractions let the model exploit
    both a low-variance summary (small keep) and a less-biased one (large keep).
    The p^2 * dedx term encodes the Bethe-Bloch mass dependence (dE/dx ~ 1/beta^2,
    so p^2 * dE/dx orders species by mass).
    """
    M = df[DEDX_COLS].values.astype(float)
    mom = df["momentum"].values.astype(float)
    tms = {k: truncated_mean(M, k) for k in (0.25, 0.40, 0.60, 0.80)}
    n_valid = np.sum(~np.isnan(M), axis=1).astype(float)
    with np.errstate(invalid="ignore"):
        log_d = np.log(tms[0.40])
        bethe = np.where(np.isnan(mom), np.nan, tms[0.40] * mom * mom)
    X = np.column_stack([
        mom,
        tms[0.25], tms[0.40], tms[0.60], tms[0.80],
        log_d,
        bethe,
        n_valid,
    ])
    feature_names = [
        "momentum", "tmean_keep25", "tmean_keep40", "tmean_keep60",
        "tmean_keep80", "log_tmean_keep40", "p2_times_dedx", "n_valid_samples",
    ]
    return X, feature_names


def make_model():
    return HistGradientBoostingClassifier(
        random_state=0, max_iter=500, learning_rate=0.04,
        max_leaf_nodes=31, l2_regularization=2.0, min_samples_leaf=40,
    )


def main():
    train = pd.read_csv("train.csv")
    test = pd.read_csv("test_input.csv")

    # --- Reported dE/dx estimate: truncated mean on each event's own samples ---
    test_dedx_est = truncated_mean(test[DEDX_COLS].values.astype(float), REPORT_KEEP)

    # --- Features and labels ---
    Xtr, feat_names = build_features(train)
    ytr = train["particle"].values
    Xte, _ = build_features(test)

    # --- Honest performance estimate: 5-fold stratified CV on TRAIN only ---
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=1)
    cv_pred = cross_val_predict(make_model(), Xtr, ytr, cv=cv)
    cv_acc = float(accuracy_score(ytr, cv_pred))
    print(f"5-fold CV accuracy: {cv_acc:.4f}")

    # --- Fit on all training data, predict test ---
    model = make_model()
    model.fit(Xtr, ytr)
    test_species = model.predict(Xte)

    # --- Save predictions (preserve event_id order exactly) ---
    out = pd.DataFrame({
        "event_id": test["event_id"].values,
        "dedx_est": test_dedx_est,
        "particle": test_species,
    })
    out.to_csv("test_pred.csv", index=False)

    summary = {
        "dedx_estimator": (
            "Truncated mean keeping the lowest 60% of each event's own dedx "
            "samples (sort, drop the top 40%, average the rest). The within-event "
            "samples are strongly right-skewed (Landau-like, median skew ~3.9), so "
            "the arithmetic mean is dominated by rare large-loss fluctuations; the "
            "truncated mean is the standard robust estimator of the true "
            "most-probable energy loss. Measured within homogeneous (species, "
            "momentum) cells its coefficient of variation is ~0.06 vs ~0.74 for the "
            "full mean."
        ),
        "model_type": "Histogram-based gradient boosted decision trees (multiclass)",
        "features": feat_names,
        "data_preparation": (
            "Per event, dedx summaries computed only from that event's non-NaN "
            "samples (valid count varies ~28-50). No arithmetic-mean summary used "
            "due to the heavy tail. Missing momentum (~4% of events) is left as NaN "
            "and handled natively by the gradient-boosting model rather than imputed. "
            "No rows dropped; every test event predicted."
        ),
        "validation": (
            f"5-fold stratified cross-validation on train.csv (model never sees the "
            f"held-out fold). Mean accuracy = {cv_acc:.4f}. Errors concentrate in "
            f"proton/kaon/deuteron whose Bethe-Bloch curves overlap in 1-10 GeV/c; "
            f"electrons (flat minimum-ionizing ~2 keV/cm) separate cleanly."
        ),
        "reasoning": (
            "The repeated measurements are a Landau distribution, so a truncated "
            "mean (not the arithmetic mean) recovers the true energy loss. Species "
            "are then separated in the (momentum, dedx) plane via Bethe-Bloch; a "
            "p^2*dedx feature encodes the mass ordering. Separation quality is "
            "momentum-dependent and some species genuinely overlap, capping accuracy."
        ),
    }
    with open("model_summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    print("Wrote test_pred.csv and model_summary.json")
    print(out.head())


if __name__ == "__main__":
    main()
