"""
Particle detector analysis.

Each event carries up to 50 repeated dE/dx (energy-loss per unit length)
measurements along one track. Energy loss in thin absorbers follows a
Landau distribution: strongly right-skewed with a long high tail from rare
large energy transfers (delta rays). The arithmetic mean is therefore a poor,
high-variance estimator of the true (most-probable) energy loss. The detector-
physics standard is the TRUNCATED MEAN: sort the per-event samples, discard the
highest fraction, and average the rest. That is what we use for `dedx_est`.

Species identification then relies on the fact that, at a given momentum,
dE/dx depends on velocity (beta*gamma = p/m), so particles of different mass
sit on different Bethe-Bloch curves. We feed the truncated-mean dE/dx together
with momentum (plus a couple of shape/robustness summaries) to a gradient-
boosted tree classifier.
"""

import json
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import cross_val_score, StratifiedKFold

TRUNC_FRAC = 0.6  # keep the lowest 60% of samples (drop the Landau tail)


def event_features(row_vals):
    """Reduce one event's repeated dE/dx measurements to summary features."""
    v = row_vals[~np.isnan(row_vals)]
    v = np.sort(v)
    n = len(v)
    k = max(1, int(np.ceil(n * TRUNC_FRAC)))
    trunc = v[:k]
    return (
        trunc.mean(),        # truncated mean  -> dedx_est (Landau-robust)
        trunc.std(),         # spread of the retained (bulk) samples
        float(np.median(v)), # median, a second robust location summary
        float(n),            # number of measurements available
    )


def build_features(df, dedx_cols):
    X = df[dedx_cols].to_numpy(dtype=float)
    feats = np.array([event_features(X[i]) for i in range(len(df))])
    out = pd.DataFrame(
        {"tmean": feats[:, 0], "tstd": feats[:, 1],
         "med": feats[:, 2], "n": feats[:, 3]}
    )
    out["momentum"] = df["momentum"].to_numpy()  # HistGBM handles NaN natively
    out["logp"] = np.log(df["momentum"].to_numpy())
    return out


def main():
    train = pd.read_csv("train.csv")
    test = pd.read_csv("test_input.csv")
    dedx_cols = [c for c in train.columns if c.startswith("dedx_")]

    feat_names = ["tmean", "tstd", "med", "n", "momentum", "logp"]

    Xtr = build_features(train, dedx_cols)[feat_names]
    ytr = train["particle"]

    # --- honest validation: 5-fold CV on data the model never trains on ---
    clf_cv = HistGradientBoostingClassifier(
        random_state=0, max_iter=300, learning_rate=0.08
    )
    cv = StratifiedKFold(5, shuffle=True, random_state=0)
    cv_scores = cross_val_score(clf_cv, Xtr.to_numpy(), ytr, cv=cv,
                                scoring="accuracy")
    cv_acc = float(cv_scores.mean())
    print(f"Cross-validated accuracy: {cv_acc:.4f} (+/- {cv_scores.std():.4f})")

    # --- fit on all training data, predict the test set ---
    clf = HistGradientBoostingClassifier(
        random_state=0, max_iter=300, learning_rate=0.08
    )
    clf.fit(Xtr.to_numpy(), ytr)

    Xte = build_features(test, dedx_cols)[feat_names]
    pred = clf.predict(Xte.to_numpy())

    out = pd.DataFrame({
        "event_id": test["event_id"],
        "dedx_est": Xte["tmean"].to_numpy(),  # truncated-mean estimate
        "particle": pred,
    })
    out.to_csv("test_pred.csv", index=False)

    summary = {
        "dedx_estimator": (
            f"Truncated mean: per event, sort the up-to-50 repeated dE/dx "
            f"samples, keep the lowest {int(TRUNC_FRAC*100)}%, and average them. "
            "dE/dx follows a right-skewed Landau distribution (long high tail "
            "from delta rays; within-event skew ~4, values up to ~7e4), so the "
            "arithmetic mean is biased and high-variance. Truncating the tail "
            "yields a stable estimate of the most-probable energy loss, the "
            "standard tracking-detector approach."
        ),
        "model_type": "Histogram-based gradient-boosted decision trees (HistGradientBoostingClassifier)",
        "features": feat_names,
        "data_preparation": (
            "Per event, dropped NaN dE/dx entries (events have 28-50 valid "
            "measurements, not always 50) before computing summaries. Momentum "
            "has missing values (203/5000 train, 68/1500 test); left as NaN "
            "because the tree model splits on missingness natively rather than "
            "imputing. No row was discarded."
        ),
        "validation": (
            f"Stratified 5-fold cross-validation on train.csv (each fold "
            f"predicted by a model trained only on the other folds). "
            f"Mean accuracy = {cv_acc:.4f}."
        ),
        "reasoning": (
            "The within-event dE/dx measurements are Landau-distributed and "
            "strongly right-skewed, so a truncated mean beats the arithmetic "
            "mean or median as both the energy-loss estimate and a classifier "
            "feature. At fixed momentum, dE/dx separates species by mass via "
            "Bethe-Bloch; electrons separate cleanly while proton/kaon/deuteron "
            "overlap in mid-momentum bands, which caps achievable accuracy."
        ),
    }
    with open("model_summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    print("Wrote test_pred.csv and model_summary.json")


if __name__ == "__main__":
    main()
